"""Native indexed courtyard art; scene palettes provide Tuscan colors."""
from pathlib import Path
from PIL import Image, ImageDraw, ImageFont
import hashlib
import json
import uuid
from make_feedback_art import table_clearance, build as build_feedback

ROOT = Path(__file__).resolve().parents[1]
level = json.loads((ROOT / 'tools/level.json').read_text())
colors = ['#e0f8cf', '#86c06c', '#306850', '#071821']
width = level['width']
im = Image.new('RGB', (width, 144), colors[0])
d = ImageDraw.Draw(im)
font = ImageFont.load_default(size=8)

def caption(x, y, text):
    # Each letter stays inside one 8px tile, so text tiles can be reused.
    for i, char in enumerate(text):
        tile = Image.new('RGB', (8, 8), colors[0])
        td = ImageDraw.Draw(tile)
        td.fontmode = '1'
        td.text((1, -1), char, fill=colors[3], font=font)
        im.paste(tile, (x + i * 8, y))

def tree(x, y=64):
    d.rectangle((x+14,y+32,x+17,127),fill=colors[2])
    d.line((x+16,y+50,x+4,y+39),fill=colors[2],width=2)
    for dx,dy in [(0,8),(16,8),(8,0),(8,24)]:
        d.ellipse((x+dx,y+dy,x+dx+15,y+dy+23),fill=colors[1])
        d.line((x+dx+4,y+dy+7,x+dx+9,y+dy+7),fill=colors[2])

# Repeated distant roof/wall tiles; leave moving objects a quiet backdrop.
for x in range(0,width,64):
    d.polygon([(x,72),(x+24,48),(x+48,72)], fill=colors[1])
    d.rectangle((x+8,72,x+39,119),fill=colors[1])
    d.rectangle((x+16,80,x+23,95),fill=colors[0])
    d.line((x+8,104,x+39,104),fill=colors[0])
for x in [24,480,864,984]:
    tree(x)
# Solid paving.
d.rectangle((0,128,width-1,143),fill=colors[2])
d.line((0,128,width-1,128),fill=colors[3])
for x in range(0,width,16):
    d.line((x,136,x+14,136),fill=colors[1])
    d.line((x+8,129,x+8,134),fill=colors[1])

for i,(left,top,right,bottom) in enumerate(level['solids']):
    if i in level['gate_indices'] or i == level['door_index']:
        continue
    if left == 1104:  # Table: leave the entire wool-ball passage visible.
        d.rectangle((left,top,right-1,bottom-1),fill=colors[1],outline=colors[3])
        d.line((left+1,top+3,right-2,top+3),fill=colors[0])
        for x in range(left+8,right-4,16):
            d.ellipse((x,top-5,x+7,top-2),fill=colors[0],outline=colors[2])
        table_clearance(d,left,top,right,bottom)
        continue
    d.rectangle((left,top,right-1,bottom-1),fill=colors[1],outline=colors[2])
    d.line((left,top,right-1,top),fill=colors[3])
    d.line((left+1,top+3,right-2,top+3),fill=colors[0])
    for y in range(top+8,bottom,8):
        d.line((left+1,y,right-2,y),fill=colors[2])
    if i in [0,1,2]:
        for x in range(left+4,right-3,8):
            d.line((x,top-6,x,top-1),fill=colors[2])
            d.rectangle((x-2,top-8,x+2,top-6),fill=colors[1])

for court in level['courts']:
    x,y,g = court['bell_x'],court['bell_y'],court['gate']
    # The thin cord connects the target to its gate latch.
    d.line([(x,y-6),(x,y-16),(g+3,y-16),(g+3,54)],fill=colors[2])
    # The bell itself is an animated actor; the cord remains background art.
    d.rectangle((g-3,40,g-1,127),fill=colors[2])
    d.rectangle((g+9,40,g+11,127),fill=colors[2])
    d.rectangle((g-5,36,g+13,40),fill=colors[1],outline=colors[2])

# The courtyard now ends at an orchard gate; the photo belongs to the finale.
for x in range(1200,1272,16):
    d.line((x,48,x+16,48),fill=colors[2])
    d.polygon([(x+2,49),(x+10,49),(x+6,56)],fill=colors[1])
tree(1216)

caption(8,24,'COLLECT WOOL')
caption(8,40,'A JUMP  B THROW')
caption(168,24,'HOLD UP TO LOB')
caption(320,24,'RING THE BELL')
caption(320,40,'UP+B LOB')
caption(488,24,'WOOL VS GOONS')
caption(488,40,'THROW + RETRIEVE')
caption(680,24,'HIGH OR LOW?')
caption(872,24,'MIND THE GAP')
caption(1032,24,'UNDER THE TABLE')
caption(1032,40,'B UNDER A OVER')
caption(1216,24,'GROVE')

# Irrigation channels: first has a safe shallow bottom; later pools respawn.
for left,right,floor in level['gaps']:
    d.rectangle((left,128,right-1,143),fill=colors[1])
    d.line((left,128,right-1,128),fill=colors[0])
    for x in range(left,right,8):
        d.line((x+1,132,x+5,132),fill=colors[0])
        d.line((x+3,137,x+7,137),fill=colors[2])
    if floor == 140:
        d.rectangle((left,140,right-1,143),fill=colors[3])
    d.line((left-1,128,left-1,143),fill=colors[3])
    d.line((right,128,right,143),fill=colors[3])
# Sparse chips and joints add texture without competing with the sprite.
for x in range(0,width,64):
    for y in (76,100,116):
        d.line((x+10,y,x+14,y),fill=colors[0])
    for xx in range(x+8,x+40,8):
        d.line((xx,68,xx+3,68),fill=colors[2])
for x in range(0,width,16):
    if not any(a<=x<b for a,b,_ in level['gaps']):
        d.point((x+3,131),fill=colors[0]);d.point((x+11,140),fill=colors[1])
dest=ROOT/'assets/backgrounds/courtyard.png'
old=ROOT/'source-art/courtyard-v1.png'
if not old.exists():
    old.write_bytes(dest.read_bytes())
im.save(dest)
im.save(ROOT/'source-art/courtyard-long.png')
metadata=dest.with_suffix('.png.gbsres')
meta=json.loads(metadata.read_text())
meta.update(name='Tuscan wedding courtyard',width=width//8,height=18,imageWidth=width,imageHeight=144)
metadata.write_text(json.dumps(meta,indent=2)+'\n')
header=ROOT/'plugins/kittie/engine/include/states/kittie_level.h'
rows=',\n '.join('{'+','.join(str(v*16) for v in r)+'}' for r in level['solids'])
header.write_text('/* Generated by tools/make_level.py. Edit tools/level.json. */\n'
    f'#define LEVEL_WIDTH {width}\n#define SOLID_COUNT {len(level["solids"])}\n'
    f'#define ENTRY_DOOR_SOLID {level["door_index"]}\n'
    f'#define FIRST_GATE_SOLID {level["gate_indices"][0]}\n#define LAST_GATE_SOLID {level["gate_indices"][1]}\n'
    f'static const INT16 solids[SOLID_COUNT][4]={{\n {rows}\n}};\n'
    + '#define BALL_COUNT 6\nstatic const INT16 ball_spawns[BALL_COUNT][2]={'
    + ','.join('{'+','.join(str(v*16) for v in r)+'}' for r in level['balls'])+'};\n'
    + '#define GAP_COUNT 3\nstatic const INT16 gaps[GAP_COUNT][3]={'
    + ','.join('{'+','.join(str(v*16) for v in r)+'}' for r in level['gaps'])+'};\n'
    + '#define GOON_COUNT 3\nstatic const INT16 goon_limits[GOON_COUNT][2]={'
    + ','.join('{'+','.join(str(v*16) for v in r)+'}' for r in level['goons'])+'};\n')

build_feedback()
tiles={im.crop((x,y,x+8,y+8)).tobytes() for y in range(0,144,8) for x in range(0,width,8)}
print(f'Background {width}x144, {len(tiles)} unique source tiles')
